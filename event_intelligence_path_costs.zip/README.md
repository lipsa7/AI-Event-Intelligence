# Per-path cost patch (8 November 2026)

Applies to the exact project files in C:\Users\DELL\Desktop\event-intelligence-ai as read on 8 November 2026
(orchestrator "v3.31.0-research-substance-ner" with the 25-26 October funnel, memory-pass and call-cap changes).
Not a cumulative package. The installer checks every file it changes byte for byte and refuses if anything
was edited since; then stop and do not force it.

## What it adds (no new checks, no model calls)
Anthropic's guidance on building agents: add complexity only when it demonstrably improves outcomes, and
measure it. Observability tools (Langfuse, LangSmith) trace cost per step for the same reason. The app has
four paths that each produce strategic items - hidden insights, the briefing, the hypothesis lab and actor
moves - and nothing measured which of them earns its Gemini calls (the 23 October replay used about 253).

- Every Gemini attempt (retries and grounded searches included) is counted against the analysis path that
  started the work: hidden_insights, briefing, hypothesis_lab, actor_moves, focus_research,
  precedent_research, judge, or pipeline (everything else). Tokens too, including Gemini's cached-prefix tokens.
- Each run appends one line to data/run_costs.jsonl; replay_run.py prints the breakdown at the end.
- replay_run.py --max-calls N: a shortcut for the existing per-run cap (EVENT_INTELLIGENCE_MAX_GEMINI_CALLS;
  optional stages stop at 85% of it).
- python path_value.py [REPORT-...]: for one report, each path's attempts beside how many of its items you rated
  useful. compare_runs.py prints the same for both runs.

Runs made before this patch have no cost line, so the table starts with the next run.

## Files
Changed: services/gemini_llm_service.py, services/research_orchestrator_service.py, replay_run.py,
compare_runs.py, docs/PRODUCT_SPEC.md. New: services/path_costs.py, path_value.py, tests/test_path_costs.py.
CHANGES.diff is the complete change.

## Tests
tests/test_path_costs.py: 7 tests, no model calls. On a copy of your current files (built from git 152e01a plus
every file you changed since), the rest of the test folder showed exactly the same failures before and after
the patch; the full suite was not run on your own machine.

## Install
```powershell
Expand-Archive .\event_intelligence_path_costs.zip .\_path_costs -Force
.\venv\Scripts\python.exe .\_path_costs\install.py --project . --check
.\venv\Scripts\python.exe .\_path_costs\install.py --project .
.\venv\Scripts\python.exe -m pytest tests\test_path_costs.py -q
```
