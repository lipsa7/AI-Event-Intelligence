# November cost and quality patch v2 (8 November 2026)

Replaces event_intelligence_path_costs.zip and the earlier event_intelligence_nov_fixes.zip (neither installed
yet - delete both; this one includes everything). Built on the exact files in
C:\Users\DELL\Desktop\event-intelligence-ai as read on 8 November 2026 (orchestrator "v3.31.0-research-substance-ner").
The installer checks every file byte for byte and refuses if anything was edited since; then stop, do not force.
Makes no model calls; never touches .env, data, reports or settings.

## 1. Per-path cost (measurement)
Every Gemini attempt and its tokens (cached-prefix tokens included) is counted against the path that started it:
hidden_insights, briefing, hypothesis_lab, actor_moves, focus_research, precedent_research, judge, pipeline.
One line per run in data/run_costs.jsonl; replay_run.py prints it and takes --max-calls N; path_value.py and
compare_runs.py set each path's cost beside how many of its items you rated useful.
Basis: Anthropic, "Building effective agents"; Langfuse/LangSmith per-span cost.

## 2. Strategic inference stops paying for discarded answers
23 Oct replay: Pro answered in 113 s against a 90 s cut-off and 3.8-flash in 277 s - both billed, both thrown
away, then the next model started from zero (nine ~29k-token calls on 8 models). Now a slow route stays in
flight while the next starts (max 2 at once, STRATEGIC_MAX_ROUTES_IN_FLIGHT); the first good answer wins,
including a late Pro answer. Basis: Dean & Barroso, "The Tail at Scale" (hedged requests, capped).

## 3. Grounding prompt: evidence first, claim last (grounding-v1.3-context-first)
167 grounding calls sent 877k prompt tokens; only 24.5k were cached. Instructions + evidence now come first and
the claim last, so calls on the same records share a prefix that Gemini's implicit cache discounts (75%, prefix
>= 1024 tokens on Flash). Google's long-context guidance also puts the question after the context.
Old reports' grounding cache keys change once (prompt version bump): the first re-check of an old item re-grounds.

## 4. Bolder originals first under "Hypotheses to investigate"
25 Oct run: the lab "verified" a narrowed restatement and buried the bolder original (the liability-shield
reading). Narrowing buys support at the cost of informativeness (factuality-specificity trade-off). Now the
bolder original leads the tier, labelled with the parts the sources do not back; the dashboard no longer
calls it "overstated".

## 5. Facts vs reasoning in the claim gate (claim-support gate v3.0) - the main objective fix
25 Oct run: all 4 candidates were rejected because the leverage and incentives were checked as FACTS a news report
must state ("the evidence does not state the purpose of the funding"). Incentives are the app's reasoning; news
rarely states them. Now (same split the hypothesis lab already uses; ICD 203 facts vs assumptions vs judgments):
- what the holder controls: a fact, must be stated;
- who depends on it: must follow from the cited facts; partly backed -> labelled assumption; not backed -> rejected;
- each side's incentive: stated or inferred passes; otherwise shown as an "inferred incentive" assumption;
- contradicted -> rejected; at most 3 assumptions per insight.
Holder and dependent must be NAMED organisations/agencies/people. The 25 Oct candidates all used categories
("Venture investors seeking exposure to AI ...") - that is what made them generic. Checked before any grounding
call (saves calls) and sent back for repair with that instruction.

## 6. Actor moves: judgments labelled, not deleted (actor-strategy v5)
13 items were removed on 25 Oct because no source states that a move "would benefit" an actor - which no source
ever will. Moves, the choice, the crux, the leverage reading and others' likely moves are now kept when their
premises are at least partly backed, labelled "judgment - its premises are partly backed by the cited facts".
Unsupported or contradicted ones are still removed; facts keep the fact bar; already-reported and generic
(swap test) moves are still removed.

## 7. Precedents: the direct precedent first, real outcomes
The search now asks first for the most recent earlier case of the same kind of instrument by the same actors
(reference-class / outside view: Kahneman and Lovallo; Neustadt and May), then a same-mechanism case. On 25 Oct it
missed the 2023 White House voluntary AI commitments and showed CISA's pledge with "68 companies signed" as its
outcome. An outcome must say what FOLLOWED the case; one that repeats the case is treated as missing, which
triggers the existing "what happened next" search.

## What this does NOT do
- It cannot make a run produce insights whose leverage the sources cannot back; those still go to "Hypotheses to
  investigate". Whether this release yields good accepted insights needs one real run and your ratings.
- No model calls were made to test it. Tests use recorded/synthetic checker verdicts.

## Files
Changed: agents/strategic_inference_agent.py, services/claim_support_gate.py, services/actor_moves.py,
services/hypothesis_evidence_service.py, services/grounding_service.py, services/hypothesis_tier.py,
frontend/dashboard.py, services/gemini_llm_service.py, services/research_orchestrator_service.py,
replay_run.py, compare_runs.py, docs/PRODUCT_SPEC.md, tests/test_claim_support_gate.py,
tests/test_v6_16_developments.py, tests/test_v6_26_leverage_incentives.py (pinned the old "leverage is a fact"
rule; now pins the typed rule), tests/test_v6_34_narrow_and_show.py.
New: services/path_costs.py, path_value.py, tests/test_path_costs.py, tests/test_strategic_hedged_routes.py,
tests/test_quality_fixes_nov.py, tests/test_typed_leverage_nov.py, tests/test_actor_judgments_nov.py,
tests/test_precedent_direct_nov.py. CHANGES.diff is the complete change.

## Tests
27 new tests pass, no model calls. On a copy of your current files the rest of the suite showed exactly the same
failures before and after (they were already failing; none caused by this patch).

## Install
```powershell
cd C:\Users\DELL\Desktop\event-intelligence-ai
Remove-Item .\event_intelligence_path_costs.zip -ErrorAction SilentlyContinue
Remove-Item .\event_intelligence_nov_fixes.zip -ErrorAction SilentlyContinue
Expand-Archive .\event_intelligence_nov_fixes_v2.zip .\_nov_fixes -Force
.\venv\Scripts\python.exe .\_nov_fixes\install.py --project . --check
.\venv\Scripts\python.exe .\_nov_fixes\install.py --project .
.\venv\Scripts\python.exe -m pytest tests\test_path_costs.py tests\test_strategic_hedged_routes.py tests\test_quality_fixes_nov.py tests\test_typed_leverage_nov.py tests\test_actor_judgments_nov.py tests\test_precedent_direct_nov.py -q
Remove-Item .\_nov_fixes -Recurse -Force
```
