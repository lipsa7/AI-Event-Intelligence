"""Typed leverage (claim-support-gate v3.0, 8 Nov 2026).

Case: the 25 Oct run (REPORT-316E7FC814727B8CCAA30C52) rejected every candidate because the
leverage and the incentives were checked as facts a source must state ("the evidence does not
state the purpose of the funding"). Control stays a fact; dependency and incentives are reasoning.
"""
from services import claim_support_gate as gate


def grounding(*claims):
    return {"review_status": "complete", "claims": [
        {"claim_id": cid, "epistemic_type": kind, "grounding_status": status, "claim_text": cid,
         "supporting_evidence_ids": ["EVID-A", "EVID-B"], "unsupported_parts": ["not stated"]}
        for cid, kind, status in claims]}


SOURCES = {"EVID-A": "S1", "EVID-B": "S2"}
BASE = [("R-P1", "fact", "supported"), ("R-INSIGHT-01", "hidden_insight", "inference_supported"),
        ("R-CONTROL", "fact", "supported")]


def test_inferred_incentive_passes_and_unstated_incentive_is_a_labelled_assumption():
    verdict = gate.evaluate(grounding(*BASE, ("R-DEPENDENCY", "connection", "inference_supported"),
                                      ("R-HOLDER-INCENTIVE", "connection", "inference_supported"),
                                      ("R-DEPENDENT-INCENTIVE", "connection", "unsupported")), SOURCES)
    assert verdict["passed"], verdict["reasons"]
    [assumption] = verdict["key_assumptions"]
    assert assumption["kind"] == "incentive" and assumption["text"].startswith("Inferred incentive")
    assert assumption["claim_id"] == "R-DEPENDENT-INCENTIVE"


def test_partly_backed_dependency_is_an_assumption_but_unbacked_dependency_blocks():
    partly = gate.evaluate(grounding(*BASE, ("R-DEPENDENCY", "connection", "partially_supported"),
                                     ("R-HOLDER-INCENTIVE", "connection", "supported")), SOURCES)
    assert partly["passed"] and partly["key_assumptions"][0]["kind"] == "dependency"
    unbacked = gate.evaluate(grounding(*BASE, ("R-DEPENDENCY", "connection", "unsupported"),
                                       ("R-HOLDER-INCENTIVE", "connection", "supported")), SOURCES)
    assert not unbacked["passed"]
    assert "leverage_dependency_not_supported_by_cited_evidence" in unbacked["reasons"]


def test_control_is_still_a_fact_and_contradiction_still_blocks():
    no_control = gate.evaluate(grounding(("R-P1", "fact", "supported"),
                                         ("R-INSIGHT-01", "hidden_insight", "inference_supported"),
                                         ("R-CONTROL", "fact", "partially_supported"),
                                         ("R-DEPENDENCY", "connection", "supported")), SOURCES)
    assert not no_control["passed"] and "premise_not_supported_by_cited_evidence" in no_control["reasons"]
    contradicted = gate.evaluate(grounding(*BASE, ("R-HOLDER-INCENTIVE", "connection", "contradicted")), SOURCES)
    assert not contradicted["passed"] and not contradicted["repairable"]


def test_assumption_limit_counts_leverage_assumptions():
    verdict = gate.evaluate(grounding(*BASE, ("R-DEPENDENCY", "connection", "partially_supported"),
                                      ("R-HOLDER-INCENTIVE", "connection", "unsupported"),
                                      ("R-DEPENDENT-INCENTIVE", "connection", "unsupported"),
                                      ("R-MECHANISM-01", "mechanism", "unsupported")),
                            SOURCES, {"EVID-A": "E1", "EVID-B": "E2"}, {"EVID-A": "P1", "EVID-B": "P2"})
    assert not verdict["passed"] and "too_many_unverified_assumptions" in verdict["reasons"]
    assert verdict["key_assumptions"] == []


def test_old_single_leverage_fact_claim_is_judged_as_before():
    verdict = gate.evaluate(grounding(("R-P1", "fact", "supported"),
                                      ("R-INSIGHT-01", "hidden_insight", "inference_supported"),
                                      ("R-LEVERAGE", "fact", "partially_supported")), SOURCES)
    assert not verdict["passed"]


def test_leverage_parties_must_be_named():
    lev = {"holder": "TypeSafe Inc. and ASI Inc.", "controls": "proprietary models",
           "dependent": "Venture investors seeking direct financial exposure to AI model infrastructure",
           "holder_incentive": "x", "predicted_move": "y"}
    assert gate.leverage_reasons({"leverage_analysis": lev}) == ["leverage_party_not_named:dependent"]
    assert gate.leverage_reasons({"leverage_analysis": dict(lev, dependent="the White House")}) == []
    assert not gate.named_party("Institutional capital providers seeking AI exposure")
    assert gate.named_party("EU regulators") and gate.named_party("Microsoft")
    assert any("NAMED" in line for line in gate.so_what_brief(["leverage_party_not_named:dependent"]))
