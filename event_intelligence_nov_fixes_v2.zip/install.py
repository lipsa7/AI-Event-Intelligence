"""Install the November cost and quality patch (per-path costs + fixes) on the exact project files reviewed on 8 November 2026.

- Every file it changes must match the reviewed version byte for byte, or nothing is written.
- New files must not already exist (unless they already match this package).
- Backs up every file it replaces, writes atomically, and rolls back on any failure.
- Never reads or changes .env, data, reports or settings. Makes no model calls.

    python install.py --project C:\\Users\\DELL\\Desktop\\event-intelligence-ai --check   (read-only)
    python install.py --project C:\\Users\\DELL\\Desktop\\event-intelligence-ai
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
NAME = "November cost and quality"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plan(project: Path, manifest: dict) -> tuple[list, list]:
    writes, problems = [], []
    for relative, spec in manifest["files"].items():
        source = PACKAGE / "files" / relative
        if not source.is_file() or sha(source) != spec["installed"]:
            problems.append(f"package file missing or changed: {relative}")
            continue
        if relative.endswith(".py"):
            compile(source.read_text(encoding="utf-8"), str(source), "exec")
        target = project / relative
        if target.exists():
            actual = sha(target)
            if actual == spec["installed"]:
                continue                                   # already installed
            if spec["expect"] is None:
                problems.append(f"{relative} already exists and differs from this package")
            elif actual != spec["expect"]:
                problems.append(f"{relative} differs from the reviewed version (edited since 8 Nov? stop, do not force)")
            else:
                writes.append((source, target, relative))
        elif spec["expect"] is not None:
            problems.append(f"{relative} is missing")
        else:
            writes.append((source, target, relative))
    return writes, problems


def atomic_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".novfix_", dir=target.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(source.read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project", type=Path, default=Path.cwd())
    parser.add_argument("--check", action="store_true", help="report what would change; write nothing")
    args = parser.parse_args()
    project = args.project.resolve()
    manifest = json.loads((PACKAGE / "manifest.json").read_text(encoding="utf-8"))
    writes, problems = plan(project, manifest)
    if problems:
        print("NOT INSTALLED - stop, do not force:\n  - " + "\n  - ".join(problems))
        return 2
    if not writes:
        print(f"The {NAME} patch is already installed.")
        return 0
    if args.check:
        print("Check passed. Would change:\n  " + "\n  ".join(r for _, _, r in writes))
        return 0
    backup = project / "v6_backups" / (datetime.now().strftime("%Y%m%d_%H%M%S") + "_before_nov_fixes")
    done = []
    try:
        for source, target, relative in writes:
            if target.exists():
                (backup / relative).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup / relative)
            atomic_copy(source, target)
            done.append((target, relative))
    except Exception as error:
        for target, relative in reversed(done):
            saved = backup / relative
            if saved.exists():
                shutil.copy2(saved, target)
            else:
                target.unlink(missing_ok=True)
        print(f"Install failed and was rolled back: {error}")
        return 1
    print(f"Installed the {NAME} patch:\n  " + "\n  ".join(r for _, r in done))
    print(f"Backups: {backup}")
    print("Check: python -m pytest tests/test_path_costs.py tests/test_strategic_hedged_routes.py tests/test_quality_fixes_nov.py tests/test_typed_leverage_nov.py tests/test_actor_judgments_nov.py tests/test_precedent_direct_nov.py -q")
    return 0


if __name__ == "__main__":
    sys.exit(main())
