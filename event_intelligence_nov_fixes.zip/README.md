# November cost and quality patch (8 November 2026)

Replaces event_intelligence_path_costs.zip (not installed yet - delete that zip). Built on the exact files in
C:\Users\DELL\Desktop\event-intelligence-ai as read on 8 November 2026 (orchestrator "v3.31.0-research-substance-ner").
The installer checks every file byte for byte and refuses if anything was edited since; then stop, do not force.
Makes no model calls; never touches .env, data, reports or settings.

## 1. Per-path cost (measurement)
Every Gemini attempt and its tokens (cached-prefix tokens included) is counted against the path that started it:
hidden_insights, briefing, hypothesis_lab, actor_moves, focus_research, precedent_research, judge, pipeline.
One line per run in data/run_costs.jsonl; replay_run.py prints it and takes --max-calls N; path_value.py and
compare_runs.py set each path's cost beside how many of its items you rated useful.
Basis: Anthropic, "Building effective agents"; Langfuse/LangSmith per-span cost.

## 2. Strategic inference stops paying for discarded answers
23 Oct replay: Pro answered in 113 s against a 90 s cut-off and 3.8-flash in 277 s - both billed, both thrown
away, then the next model started from zero (nine ~29k-token calls on 8 models). Now a slow route stays in
flight while the next starts (max 2 at once, STRATEGIC_MAX_ROUTES_IN_FLIGHT); the first good answer wins,
including a late Pro answer. Basis: Dean & Barroso, "The Tail at Scale" (hedged requests, capped).

## 3. Grounding prompt: evidence first, claim last (grounding-v1.3-context-first)
167 grounding calls sent 877k prompt tokens; only 24.5k were cached. Instructions + evidence now come first and
the claim last, so calls on the same records share a prefix that Gemini's implicit cache discounts (75%, prefix
>= 1024 tokens on Flash). Google's long-context guidance also puts the question after the context.
Old reports' grounding cache keys change once (prompt version bump): the first re-check of an old item re-grounds.

## 4. Bolder originals first under "Hypotheses to investigate"
25 Oct run: the lab "verified" a narrowed restatement and buried the bolder original (the liability-shield
reading). Narrowing buys support at the cost of informativeness (factuality-specificity trade-off). Now the
bolder original leads the tier, labelled with the parts the sources do not back; the dashboard no longer
calls it "overstated".

## Files
Changed: agents/strategic_inference_agent.py, services/grounding_service.py, services/hypothesis_tier.py,
frontend/dashboard.py, services/gemini_llm_service.py, services/research_orchestrator_service.py,
replay_run.py, compare_runs.py, docs/PRODUCT_SPEC.md, tests/test_claim_support_gate.py,
tests/test_v6_16_developments.py, tests/test_v6_34_narrow_and_show.py.
New: services/path_costs.py, path_value.py, tests/test_path_costs.py, tests/test_strategic_hedged_routes.py,
tests/test_quality_fixes_nov.py. CHANGES.diff is the complete change.

## Tests
15 new tests pass, no model calls. On a copy of your current files the rest of the suite showed exactly the same
failures before and after (they were already failing; none caused by this patch).

## Install
```powershell
cd C:\Users\DELL\Desktop\event-intelligence-ai
Remove-Item .\event_intelligence_path_costs.zip -ErrorAction SilentlyContinue
Expand-Archive .\event_intelligence_nov_fixes.zip .\_nov_fixes -Force
.\venv\Scripts\python.exe .\_nov_fixes\install.py --project . --check
.\venv\Scripts\python.exe .\_nov_fixes\install.py --project .
.\venv\Scripts\python.exe -m pytest tests\test_path_costs.py tests\test_strategic_hedged_routes.py tests\test_quality_fixes_nov.py -q
Remove-Item .\_nov_fixes -Recurse -Force
```
